# my_krml_25544646

creating custom package using testpypi for assessment 1 in advanced machine learning subject at uts 2025

## Installation

```bash
$ pip install my_krml_25544646
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`my_krml_25544646` was created by kittituch wongwatcharapaiboon. It is licensed under the terms of the MIT license.

## Credits

`my_krml_25544646` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
